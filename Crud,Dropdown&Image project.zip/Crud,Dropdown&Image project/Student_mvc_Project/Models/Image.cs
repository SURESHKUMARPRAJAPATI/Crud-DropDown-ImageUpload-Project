﻿using System.ComponentModel.DataAnnotations;

namespace Student_mvc_Project.Models
{
    public class Image
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]

        public string Name { get; set; }
        [Required(ErrorMessage = "Please Choose Image/file")]
        [Display(Name = "Choose Image")]

        public string ImagePath { get; set; }
    }
}
