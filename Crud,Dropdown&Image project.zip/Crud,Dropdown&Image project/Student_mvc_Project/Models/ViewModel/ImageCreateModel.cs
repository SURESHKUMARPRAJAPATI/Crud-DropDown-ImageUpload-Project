﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace Student_mvc_Project.Models.ViewModel
{
    public class ImageCreateModel
    {
        
        public int Id { get; set; }
        [Required(ErrorMessage ="Please Enter Name")]
        public string Name { get; set; }
        [Required(ErrorMessage ="Please Choose Image/file")]
        [Display(Name ="Choose Image")]
        public IFormFile ImagePath { get; set; }
    }
}

