﻿using Microsoft.AspNetCore.Mvc;
using Student_mvc_Project.Models;
using System.Linq;

namespace Student_mvc_Project.Controllers
{
    public class CascadeController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public CascadeController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public JsonResult Country()
        {
            var cnt = dbContext.Countries.ToList();
            return new JsonResult(cnt);
        }
        public JsonResult State(int id)
        {
            var st= dbContext.States.Where(e => e.Country.Id == id).ToList();
            return new JsonResult(st);
        }
        public JsonResult City(int id)
        {
            var ct=dbContext.Cities.Where(e=>e.State.Id == id).ToList();
            return new JsonResult(ct);
        }
        public IActionResult CascadeDropdown()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
