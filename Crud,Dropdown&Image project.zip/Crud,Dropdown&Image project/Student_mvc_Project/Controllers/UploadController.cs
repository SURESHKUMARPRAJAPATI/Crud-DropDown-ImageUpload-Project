﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Student_mvc_Project.Models;
using Student_mvc_Project.Models.ViewModel;
using System.IO;
using System.Linq;

namespace Student_mvc_Project.Controllers
{
    public class UploadController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        private readonly IHostingEnvironment environment;

        public UploadController(ApplicationDbContext dbContext,IHostingEnvironment environment)
        {
            this.dbContext = dbContext;
            this.environment = environment;
        }
        [HttpGet]
        public IActionResult UploadImage()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UploadImage(ImageCreateModel model)
        {
            string Name = Request.Form["Name"];
            string ImagePath = Request.Form["ImagePath"];
            var file = Request.Form.Files;
            string dbpath = string.Empty;
            if (file.Count > 0)
            {

            
          RedirectToAction("Index");

            var files = file[0];
                string path = environment.WebRootPath;
                string fullpath = Path.Combine(path, "Image", files.FileName);
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files.CopyTo(stream);
                dbpath=files.FileName;
            }
            var img = new Image()
            
            {
                Name = Name,
                ImagePath = dbpath          
            };

               dbContext.Add(img);
               dbContext.SaveChanges();
               return RedirectToAction("Index");
        }

        
        public IActionResult Index()
        {
            var data = dbContext.Images.ToList();
            return View(data);
        }
        public IActionResult Delete(int Id)
        {
            var img = dbContext.Images.SingleOrDefault(x => x.Id == Id);
            if (img != null)
            {
                dbContext.Images.Remove(img);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        public IActionResult Update(int Id)
        {
            var img = dbContext.Images.SingleOrDefault(x => x.Id == Id);

            return View(img);
        }
        [HttpPost]
        public IActionResult Upload(Image img)
        {
            dbContext.Images.Update(img);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
