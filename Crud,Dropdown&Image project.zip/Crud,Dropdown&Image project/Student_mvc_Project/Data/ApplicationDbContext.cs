﻿using Microsoft.EntityFrameworkCore;
using Student_mvc_Project.Models.Cascade;

namespace Student_mvc_Project.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>
            options) : base(options) { }
        
            public DbSet<Student> Student { get; set; }
            public DbSet<Image> Images { get; set; }
            public DbSet<Country>Countries { get; set; }
            public DbSet<State>States { get; set; }
            public DbSet<City> Cities { get; set; }
        }
    }

